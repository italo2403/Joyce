import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/material.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // await Firebase
  // .initializeApp(); // Adicione essa linha para inicializar o Firebase
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: LoginPage(),
  ));
}

class LoginPage extends StatefulWidget {
  LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController senhaController = TextEditingController();
  String email = '';
  String senha = '';

  // final CollectionReference users =
  //     FirebaseFirestore.instance.collection('users');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      body: Container(
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.all(27),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.deepPurple, Color(0xff6940ff)],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 30),
            Text(
              "Economizando",
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
            const SizedBox(height: 20),
            const Text(
              "Digite os dados de acesso nos campos abaixo.",
              style: TextStyle(color: Colors.white),
            ),
            const SizedBox(height: 30),
            _buildTextField(context, "Digite o seu e-mail", emailController,
                onChanged: (value) {
              setState(() {
                email = value;
              });
            }),
            const SizedBox(height: 5),
            _buildTextField(context, "Digite sua senha", senhaController,
                obscureText: true, onChanged: (value) {
              setState(() {
                senha = value;
              });
            }),
            const SizedBox(height: 30),
            _buildButton(context, "Acessar", () {
              _showDialog(context, 'Acesso',
                  'Bem vindo(a)! Email: $email, Senha: $senha');
              // _addUser(email, senha);
            }),
            const SizedBox(height: 7),
            _buildButton(context, "Crie sua conta", () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => Cadastro()));
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(BuildContext context, String placeholder,
      TextEditingController controller,
      {bool obscureText = false, Function(String)? onChanged}) {
    return TextField(
      controller: controller,
      cursorColor: const Color(0xff000000),
      decoration: InputDecoration(
        hintText: placeholder,
        hintStyle: const TextStyle(color: Colors.white70, fontSize: 14),
        filled: true,
        fillColor: Colors.black12,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(7),
          borderSide: BorderSide.none,
        ),
      ),
      style: const TextStyle(color: Colors.white, fontSize: 14),
      obscureText: obscureText,
      onChanged: onChanged,
    );
  }

  Widget _buildButton(
      BuildContext context, String text, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: Colors.greenAccent,
          onPrimary: Colors.black45,
          padding: const EdgeInsets.all(17),
        ),
        onPressed: onPressed,
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  void _showDialog(BuildContext context, String title, String content) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(content),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => Janeiro()));
              },
              child: const Text("Continuar"),
            ),
          ],
        );
      },
    );
  }

  // Future<void> _addUser(String email, String senha) {
  //   return users
  //       .add({
  //         'email': email,
  //         'senha': senha,
  //       })
  //       .then((value) => print("Usuário adicionado com ID: ${value.id}"))
  //       .catchError((error) => print("Erro ao adicionar usuário: $error"));
  // }
}

class Cadastro extends StatefulWidget {
  Cadastro({Key? key}) : super(key: key);

  @override
  _CadastroState createState() => _CadastroState();
}

class _CadastroState extends State<Cadastro> {
  final TextEditingController nomeController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController senhaController = TextEditingController();
  final TextEditingController repetirSenhaController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      body: Container(
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.all(27),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.deepPurple, Color(0xff6940ff)],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 30),
            const Text(
              "Preencha os campos abaixo com seus dados",
              style: TextStyle(color: Colors.white),
            ),
            const SizedBox(height: 30),
            _buildTextField(
              context,
              "Digite o seu nome",
              nomeController,
            ),
            const SizedBox(height: 5),
            _buildTextField(
              context,
              "Digite seu e-mail",
              emailController,
              onChanged: (value) {
                // Você pode adicionar lógica aqui para lidar com a alteração do campo de e-mail
              },
            ),
            const SizedBox(height: 5),
            _buildTextField(
              context,
              "Digite sua senha",
              senhaController,
              obscureText: true,
              onChanged: (value) {
                // Você pode adicionar lógica aqui para lidar com a alteração do campo de senha
              },
            ),
            const SizedBox(height: 5),
            _buildTextField(
              context,
              "Repita sua senha",
              repetirSenhaController,
              obscureText: true,
              onChanged: (value) {
                // Você pode adicionar lógica aqui para lidar com a alteração do campo de repetir senha
              },
            ),
            const SizedBox(height: 30),
            _buildButton(context, "Acessar", () {
              _showDialog(context, 'Acesso',
                  '${nomeController.text} finalizou seu cadastro!');
            }),
            const SizedBox(height: 7),
            _buildButton(context, "Voltar", () {
              Navigator.pop(context);
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(BuildContext context, String placeholder,
      TextEditingController controller,
      {bool obscureText = false, Function(String)? onChanged}) {
    return TextField(
      controller: controller,
      cursorColor: const Color(0xff000000),
      decoration: InputDecoration(
        hintText: placeholder,
        hintStyle: const TextStyle(color: Colors.white70, fontSize: 14),
        filled: true,
        fillColor: Colors.black12,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(7),
          borderSide: BorderSide.none,
        ),
      ),
      style: const TextStyle(color: Colors.white, fontSize: 14),
      obscureText: obscureText,
      onChanged: onChanged,
    );
  }

  Widget _buildButton(
      BuildContext context, String text, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: Colors.greenAccent,
          onPrimary: Colors.black45,
          padding: const EdgeInsets.all(17),
        ),
        onPressed: onPressed,
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  void _showDialog(BuildContext context, String title, String content) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(content),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => Janeiro()));
              },
              child: const Text("Continuar"),
            ),
          ],
        );
      },
    );
  }
}

class Task {
  final String titulo;
  final String valor;

  Task({required this.titulo, required this.valor});

  Future<void> saveToFirestore() async {
    try {
      await FirebaseFirestore.instance.collection('tasks').add({
        'titulo': titulo,
        'valor': valor,
      });
      print('Task saved to Firestore successfully!');
    } catch (e) {
      print('Error saving task to Firestore: $e');
    }
  }

  static Future<List<Task>> fetchTasksFromFirestore() async {
    List<Task> tasks = [];
    try {
      QuerySnapshot<Map<String, dynamic>> querySnapshot =
          await FirebaseFirestore.instance.collection('tasks').get();
      querySnapshot.docs.forEach((doc) {
        tasks.add(Task(
          titulo: doc['titulo'],
          valor: doc['valor'],
        ));
      });
      print('Tasks fetched from Firestore successfully!');
    } catch (e) {
      print('Error fetching tasks from Firestore: $e');
    }
    return tasks;
  }
}

class Janeiro extends StatefulWidget {
  Janeiro({Key? key}) : super(key: key);

  @override
  _JaneiroState createState() => _JaneiroState();
}

class _JaneiroState extends State<Janeiro> {
  List<Task> tasks = [];

  final TextEditingController _tituloController = TextEditingController();
  final TextEditingController _valorController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  void _showAddTaskDialog(BuildContext context) {
    String titulo = '';
    String valor = '';

    showDialog(
      context: context,
      builder: (context) {
        TextEditingController tituloController = TextEditingController();
        TextEditingController valorController = TextEditingController();

        return AlertDialog(
          title: Text('Adicionar Despesas'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: tituloController,
                decoration: InputDecoration(
                  labelText: 'Título',
                  labelStyle:
                      TextStyle(color: Color(0xff000000)), // Cor do título
                ),
                style: TextStyle(color: Color(0xff000000)), // Cor do texto
                onChanged: (value) {
                  titulo = value;
                },
              ),
              TextField(
                controller: valorController,
                decoration: InputDecoration(
                  labelText: 'Valor',
                  labelStyle:
                      TextStyle(color: Color(0xff000000)), // Cor do título
                ),
                style: TextStyle(color: Color(0xff000000)), // Cor do texto
                keyboardType: TextInputType.numberWithOptions(
                    decimal: true), // Apenas números e ponto
                // inputFormatters: [
                //   FilteringTextInputFormatter.allow(
                //       RegExp(r'^\d*[\.,]?\d{0,2}'))
                // ], // Formato de dinheiro com até duas casas decimais
                onChanged: (value) {
                  valor = value.replaceAll(
                      ',', '.'); // Substituir vírgula por ponto
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                if (titulo.isNotEmpty && valor.isNotEmpty) {
                  setState(() {
                    tasks.add(Task(titulo: titulo, valor: 'R\$ $valor'));
                  });
                  Navigator.of(context)
                      .pop(); // Fecha o diálogo após adicionar a despesa
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Despesa adicionada com sucesso!'),
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Por favor, preencha todos os campos.'),
                    ),
                  );
                }
              },
              child: Text('Adicionar'),
            ),
          ],
        );
      },
    );
  }

  void _showEditTaskDialog(BuildContext context, Task task, int index) {
    _tituloController.text = task.titulo;
    _valorController.text = task.valor.substring(3); // Remove o "R$ "

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Editar Despesa'),
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: _tituloController,
                    decoration: InputDecoration(
                      labelText: 'Título',
                      labelStyle:
                          TextStyle(color: Color(0xff000000)), // Cor do título
                    ),
                    style: TextStyle(color: Color(0xff000000)), // Cor do texto
                    onChanged: (value) {
                      // Não é necessário atualizar a variável titulo
                    },
                  ),
                  TextField(
                    controller: _valorController,
                    decoration: InputDecoration(
                      labelText: 'Valor',
                      labelStyle:
                          TextStyle(color: Color(0xff000000)), // Cor do título
                    ),
                    style: TextStyle(color: Color(0xff000000)), // Cor do texto
                    keyboardType: TextInputType.numberWithOptions(
                        decimal: true), // Apenas números e ponto
                    // inputFormatters: [
                    //   FilteringTextInputFormatter.allow(
                    //       RegExp(r'^\d*[\.,]?\d{0,2}'))
                    // ], // Formato de dinheiro com até duas casas decimais
                    onChanged: (value) {
                      // Não é necessário atualizar a variável valor
                    },
                  ),
                ],
              );
            },
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                if (_tituloController.text.isNotEmpty &&
                    _valorController.text.isNotEmpty) {
                  setState(() {
                    tasks[index] = Task(
                        titulo: _tituloController.text,
                        valor: 'R\$ ${_valorController.text}');
                  });
                  Navigator.of(context).pop(); // Fecha o diálogo após editar
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Despesa editada com sucesso!'),
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Por favor, preencha todos os campos.'),
                    ),
                  );
                }
              },
              child: Text('Salvar'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Janeiro'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              _showAddTaskDialog(context);
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: tasks.length,
        itemBuilder: (context, index) {
          final task = tasks[index];
          return ListTile(
            title: Text(task.titulo),
            subtitle: Text(task.valor),
            trailing: IconButton(
              icon: Icon(Icons.edit),
              onPressed: () {
                _showEditTaskDialog(context, task, index);
              },
            ),
          );
        },
      ),
    );
  }
}
