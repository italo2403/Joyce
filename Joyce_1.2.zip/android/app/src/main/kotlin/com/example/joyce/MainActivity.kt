package com.example.joyce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
